import pandas as pd
import datetime
import os

# LOC = locations of file to use
# Place primary file in A_LOC
# Matched and non-matched rows will be picked from
# the primary file A_LOC
A_LOC = r"C:\Users\PAVILION\Desktop\NYUMBA.xlsx"  # primary file
B_LOC = r"C:\Users\PAVILION\Desktop\SOSI.xlsx"

# Row number of Header (starts from 1)
A_HEADER_ROW = 1
B_HEADER_ROW = 1

# Header name of column to checks
A_COL_NAME = "LPO"
B_COL_NAME = "LPO"


# files stored in folder with syntax
# Hour-Minute-Second.date-month-year
# Change DESKTOP_PATH to change location of stored data
DESKTOP_PATH = r"C:\Users\Pavilion\Desktop"
today_date = datetime.datetime.now()
today_day = today_date.strftime("%H-%M-%S.%d-%B-%Y")
folder_path = os.path.join(DESKTOP_PATH, today_day)
os.mkdir(folder_path)
MATCHES_FILE = os.path.join(folder_path, 'matches.xlsx')
NON_MATCHES_FILE = os.path.join(folder_path, 'non_matches.xlsx')
LOG_FILE = os.path.join(folder_path, 'log.txt')


def output_log():
    """Write log for script to LOG_FILE."""
    log_str = ("Contents:\n"
               f"Input file 1: {A_LOC}\n"
               f"Input file 2: {B_LOC}\n"
               f"Rows where {A_COL_NAME} has matches in"
               f"{B_LOC} {B_COL_NAME}: {MATCHES_FILE}\n"
               f"NB: if {MATCHES_FILE} does not exist, no matches were found\n"
               f"Rows where {A_COL_NAME} does not have matches in"
               f"{B_LOC} {B_COL_NAME}: {NON_MATCHES_FILE}\n"
               f"NB: if {NON_MATCHES_FILE} does not exist, no empty values were found."
               )
    with open(LOG_FILE, 'w+') as f:
        f.write(log_str)


def compare_dfs(a_df, b_df):
    """Compare values in COL_NAME between A_LOC and B_LOC.

    Output matched values to MATCHES_FILE.
    Output non-matched values to NON_MATCHES_FILE.
    """
    b_values = b_df[B_COL_NAME].values.astype(str)
    a_df["check"] = a_df[A_COL_NAME].map(lambda x: str(x) in b_values)

    matched_df = a_df[a_df["check"] == True]
    matched_df = matched_df.drop(["check"], axis=1)
    if not matched_df.empty:
        matched_df.to_excel(MATCHES_FILE)

    unmatched_df = a_df[a_df["check"] == False]
    unmatched_df = unmatched_df.drop(["check"], axis=1)
    if not unmatched_df.empty:
        unmatched_df.to_excel(NON_MATCHES_FILE)


if __name__ == "__main__":
    a_df = pd.read_excel(A_LOC, header=A_HEADER_ROW-1)
    b_df = pd.read_excel(B_LOC, header=B_HEADER_ROW-1)

    compare_dfs(a_df, b_df)
    output_log()
